import styled from 'styled-components'
import Skills  from './Components/Pages/Skills/Skills';
import Home from "./Components/Pages/Home/Home";
import Portfolio from './Components/Pages/Portfolio/Portfolio';
import Header from './Components/Features/Header/Header';
import Sidebar from './Components/Features/Sidebar/Sidebar';

const StyledMainApp = styled.div`
  display: flex;
  flex-direction: column;
`

function App() {
  return (
    <StyledMainApp>
      <Header />
      <Sidebar/>
      <Home />
      <Portfolio />
      <Skills />
    </StyledMainApp>
  );
}

export default App;