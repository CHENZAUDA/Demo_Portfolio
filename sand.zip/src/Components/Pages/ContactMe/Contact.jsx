import Input from '../../Features/Input'
function Contact() {

    return (
       <Input/>
    )
}
export default Contact