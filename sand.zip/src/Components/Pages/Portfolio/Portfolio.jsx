import styled from 'styled-components'
import { MiniPage, SecondaryButton } from '../../Features/Common/CommonStyles';

const StyledHireMeMiniPage = styled.div`
    width: 100%;
    height: 80%;
    background-position: 100%;
    position: relative;
    justify-content: center;
    align-items: center;
`;

const MainHireMeMiniPage = styled.div`
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    position: absolute;
    h2 {
        color: #fff;
        font-size: 50px;
        margin-bottom: 16px;
    }
`;

const Darken = styled.div`
    width: 100%;
    height: 100%;
    position: absolute;
    background-color: black;
    opacity: 0.6;
`;

function Portfolio() {
    return (
        //project
      <MiniPage>
          <StyledHireMeMiniPage>
            <Darken></Darken>
            <MainHireMeMiniPage>
                <h2>calculter.</h2>
                <div style={{display:"flex",flexDirection:"row"}}>
                <SecondaryButton><a href="">Github</a></SecondaryButton>
                <SecondaryButton><a href="">Site</a></SecondaryButton>
                </div>
            </MainHireMeMiniPage>

            <MainHireMeMiniPage>
                <h2>project 2</h2>
                <div style={{display:"flex",flexDirection:"row"}}>
                <SecondaryButton><a href="">Github</a></SecondaryButton>
                <SecondaryButton><a href="">Site</a></SecondaryButton>
                </div>
            </MainHireMeMiniPage>

            <MainHireMeMiniPage>
                <h2>project 3 .</h2>
                <div style={{display:"flex",flexDirection:"row"}}>
                <SecondaryButton><a href="">Github</a></SecondaryButton>
                <SecondaryButton><a href="">Site</a></SecondaryButton>
                </div>
            </MainHireMeMiniPage>
          </StyledHireMeMiniPage>
      </MiniPage>
    );
  }
  
  export default Portfolio;