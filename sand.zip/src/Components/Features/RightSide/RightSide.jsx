import styled from 'styled-components';
import Sidebar from '../Sidebar/Sidebar';
import Portfolio from '../../Pages/Portfolio/Portfolio';
import Home from '../../Pages/Home/Home'
// import ImagesPage from './ImagesPage';
import { useState } from 'react';

const RightSideContainer = styled.div`
    display: flex;
    flex-direction: column;
    width: 60%;
    height: 100%;
    justify-content: flex-start;
    align-items: center;
    background: #fff;
    border-radius: 32px;
    position: relative;
`;

const PageWrapper = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 64px;
    width: 100%;
    height: 100%;
    box-sizing: border-box;
`;

function RightSide() {

  const [currentPage, setCurrentPage] = useState('home')

  const renderPage = () => {
    switch (currentPage) {
      case "home":
        return <Home />
      case "me":
        return <Portfolio />
    //   case "images":
        // return <ImagesPage />
      default:
        return <Portfolio />
    }
  }

  const changePage = (page) => {
    setCurrentPage(page);
  }

  return (
    <RightSideContainer>
        <Sidebar onChangePage={changePage}></Sidebar>
        <PageWrapper>
            {renderPage()}
        </PageWrapper>
    </RightSideContainer>
  );
}

export default RightSide;